# AETL — Advocacy for Ethical & Transformative Leadership

Starter website for AETL, an independent personal publishing and advocacy platform.

## GitHub → Netlify

1. Create a GitHub repository named `aetl-website`.
2. Upload every file in this folder to the repository root.
3. In Netlify choose **Add new project → Import an existing project**.
4. Select GitHub and the `aetl-website` repository.
5. Leave **Build command** blank.
6. Set **Publish directory** to `.`.
7. Deploy.

## Before launch

- Replace the placeholder content in `paper-001.html` with the final AETL Opinion Paper No. 001.
- Add the public contact email in `contact.html`.
- Add the final AETL logo and professional photograph when ready.
- Do not claim ISSN, DOI, indexing, or peer review unless actually obtained.
